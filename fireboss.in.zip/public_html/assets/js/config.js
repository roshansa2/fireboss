/* ============================================================
   FIRE BOSS — site settings
   Edit the values below; every WhatsApp / call / email button
   on the site reads from here.
   ============================================================ */
window.FIREBOSS = {
  brand: "Fire Boss",

  // WhatsApp number: country code + number, digits only (no + or spaces)
  whatsapp: "918249957373",

  // Shown in the enquiry / contact forms
  phones: ["8249957373", "8839930381", "9776359048"],
  email: "office.fireboss100@gmail.com",

  // First message customers see when they tap any WhatsApp button
  defaultMessage:
    "Hello Fire Boss, I would like to know more about your fire safety products & services."
};
