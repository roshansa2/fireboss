/* FIRE BOSS — site behaviour (no dependencies) */
(function () {
  "use strict";
  var CFG = window.FIREBOSS || {};
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  document.documentElement.classList.add("js");

  /* ---------- helpers ---------- */
  function waLink(msg) {
    return "https://wa.me/" + (CFG.whatsapp || "") + "?text=" + encodeURIComponent(msg || CFG.defaultMessage || "");
  }
  function store(key, val) {
    try {
      if (val === undefined) { return JSON.parse(localStorage.getItem(key)); }
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) { return null; }
  }
  function flag(key, val) {
    try {
      if (val === undefined) { return sessionStorage.getItem(key); }
      sessionStorage.setItem(key, val);
    } catch (e) { return null; }
  }
  var toastTimer;
  function toast(msg) {
    var t = $("#toast");
    if (!t) return;
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove("show"); }, 3600);
  }

  /* ---------- WhatsApp links ---------- */
  function wireWhatsApp() {
    $$("a[data-wa]").forEach(function (a) {
      var custom = a.getAttribute("data-wa-msg");
      var msg = custom || (CFG.defaultMessage + (a.hasAttribute("data-wa-page") ? "\n(Page: " + document.title.split("|")[0].trim() + ")" : ""));
      a.href = waLink(msg);
      a.target = "_blank";
      a.rel = "noopener";
    });
  }

  /* ---------- header: sticky shadow + mobile nav ---------- */
  function initHeader() {
    var header = $(".site-header");
    var onScroll = function () { header && header.classList.toggle("scrolled", window.scrollY > 8); };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    var toggle = $(".nav-toggle"), nav = $("#primary-nav");
    if (!toggle || !nav) return;
    function setOpen(open) {
      toggle.setAttribute("aria-expanded", open);
      nav.classList.toggle("open", open);
    }
    toggle.addEventListener("click", function () { setOpen(toggle.getAttribute("aria-expanded") !== "true"); });
    $$("a", nav).forEach(function (a) { a.addEventListener("click", function () { setOpen(false); }); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") setOpen(false); });
    window.addEventListener("resize", function () { if (window.innerWidth > 980) setOpen(false); });
  }

  /* ---------- reveal on scroll + counters ---------- */
  function initReveal() {
    var els = $$(".reveal");
    if (!("IntersectionObserver" in window)) { els.forEach(function (e) { e.classList.add("in"); }); return; }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    els.forEach(function (el, i) {
      if (!el.style.getPropertyValue("--d")) el.style.setProperty("--d", ((i % 4) * 0.08) + "s");
      io.observe(el);
    });
  }

  function initCounters() {
    $$("[data-years-since]").forEach(function (el) {
      var y = new Date().getFullYear() - parseInt(el.getAttribute("data-years-since"), 10);
      el.textContent = y + "+";
    });
  }

  /* ---------- enquiry list ---------- */
  var KEY = "fireboss_enquiry_v1";
  var list = store(KEY) || [];
  if (!Array.isArray(list)) list = [];

  function enquiryMessage(extra) {
    var lines = ["Hello Fire Boss, I would like a quote for the following:", ""];
    list.forEach(function (it, i) { lines.push((i + 1) + ". " + it.name); });
    lines.push("", "Please share pricing & availability.");
    if (extra) lines.push("", extra);
    return lines.join("\n");
  }

  function renderEnquiry() {
    var n = list.length;
    $$(".enq-count").forEach(function (c) { c.textContent = n; c.setAttribute("data-n", n); });

    $$(".btn-add").forEach(function (b) {
      var on = list.some(function (it) { return it.id === b.getAttribute("data-id"); });
      b.setAttribute("aria-pressed", on ? "true" : "false");
      var lbl = $(".lbl-t", b);
      if (lbl) lbl.textContent = on ? "Added" : "Add to enquiry";
    });

    var body = $("#drawer-items"), foot = $("#drawer-foot");
    if (body) {
      if (!n) {
        body.innerHTML = '<div class="drawer-empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><rect x="5" y="4" width="14" height="17" rx="1"/><path d="M9 4V3h6v1M9 10h6M9 14h6M9 18h3"/></svg>Your enquiry list is empty.<br>Tap <b>Add to enquiry</b> on any product to build a quote request.</div>';
      } else {
        body.innerHTML = list.map(function (it) {
          return '<div class="q-item"><span>' + escapeHtml(it.name) + '</span><button type="button" data-remove="' + escapeHtml(it.id) + '" aria-label="Remove ' + escapeHtml(it.name) + '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>';
        }).join("");
      }
    }
    if (foot) foot.hidden = !n;

    var sum = $("#enq-summary");
    if (sum) {
      sum.hidden = !n;
      var ol = $("ol", sum);
      if (ol) ol.innerHTML = list.map(function (it) { return "<li>" + escapeHtml(it.name) + "</li>"; }).join("");
    }
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; });
  }

  function toggleItem(id, name) {
    var idx = -1;
    list.forEach(function (it, i) { if (it.id === id) idx = i; });
    if (idx > -1) { list.splice(idx, 1); toast("Removed from your enquiry list"); }
    else { list.push({ id: id, name: name }); toast("Added to your enquiry list (" + list.length + ")"); }
    store(KEY, list);
    renderEnquiry();
  }

  function initEnquiry() {
    var drawer = $("#enquiry-drawer"), scrim = $("#scrim");
    var lastFocus = null;
    function open() {
      if (!drawer) return;
      lastFocus = document.activeElement;
      drawer.classList.add("open"); scrim.classList.add("open");
      drawer.setAttribute("aria-hidden", "false");
      var c = $("#drawer-close"); c && c.focus();
      document.body.style.overflow = "hidden";
    }
    function close() {
      if (!drawer) return;
      drawer.classList.remove("open"); scrim.classList.remove("open");
      drawer.setAttribute("aria-hidden", "true");
      document.body.style.overflow = "";
      lastFocus && lastFocus.focus && lastFocus.focus();
    }
    document.addEventListener("click", function (e) {
      var add = e.target.closest(".btn-add");
      if (add) { toggleItem(add.getAttribute("data-id"), add.getAttribute("data-name")); return; }
      var rm = e.target.closest("[data-remove]");
      if (rm) {
        var id = rm.getAttribute("data-remove");
        list = list.filter(function (it) { return it.id !== id; });
        store(KEY, list); renderEnquiry(); return;
      }
      if (e.target.closest("[data-open-enquiry]")) { open(); return; }
      if (e.target.closest("[data-close-enquiry]") || e.target === scrim) { close(); return; }
      if (e.target.closest("[data-clear-enquiry]")) { list = []; store(KEY, list); renderEnquiry(); toast("Enquiry list cleared"); return; }
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && drawer && drawer.classList.contains("open")) close();
    });
    var send = $("#drawer-send");
    if (send) {
      send.addEventListener("click", function (e) {
        e.preventDefault();
        if (!list.length) return;
        window.open(waLink(enquiryMessage()), "_blank", "noopener");
      });
    }
    renderEnquiry();
  }

  /* ---------- product filter + search ---------- */
  function initProducts() {
    var grid = $("#product-grid");
    if (!grid) return;
    var cards = $$(".pcard", grid);
    var chips = $$(".filters button");
    var input = $("#p-search");
    var countEl = $("#p-count"), empty = $("#p-empty"), note = $("#isi-note");
    var state = { cat: "all", q: "" };
    var valid = chips.map(function (c) { return c.getAttribute("data-filter"); });

    function apply() {
      var shown = 0;
      var q = state.q.trim().toLowerCase();
      cards.forEach(function (c) {
        var okCat = state.cat === "all" || c.getAttribute("data-cat") === state.cat;
        var okQ = !q || c.getAttribute("data-search").indexOf(q) > -1;
        var show = okCat && okQ;
        c.hidden = !show;
        if (show) shown++;
      });
      countEl.textContent = shown;
      empty.hidden = shown !== 0;
      grid.hidden = shown === 0;
      chips.forEach(function (c) { c.setAttribute("aria-pressed", c.getAttribute("data-filter") === state.cat ? "true" : "false"); });
      if (note) note.hidden = !(state.cat === "all" || state.cat === "extinguishers");
    }

    chips.forEach(function (c) {
      c.addEventListener("click", function () {
        state.cat = c.getAttribute("data-filter");
        try { history.replaceState(null, "", state.cat === "all" ? location.pathname : "#" + state.cat); } catch (e) {}
        apply();
      });
    });
    input.addEventListener("input", function () { state.q = input.value; apply(); });
    var reset = $("#p-reset");
    reset && reset.addEventListener("click", function () { state = { cat: "all", q: "" }; input.value = ""; apply(); });

    function fromHash() {
      var h = location.hash.replace("#", "");
      if (valid.indexOf(h) > -1) state.cat = h;
    }
    window.addEventListener("hashchange", function () { fromHash(); apply(); });
    fromHash();
    apply();
  }

  /* ---------- contact form ---------- */
  function initContact() {
    var form = $("#contact-form");
    if (!form) return;
    function field(name) { return form.elements[name]; }
    function setErr(name, bad) {
      var f = field(name).closest(".field");
      f.classList.toggle("invalid", bad);
    }
    function validate() {
      var ok = true;
      var name = field("name").value.trim();
      var phone = field("phone").value.replace(/[\s\-()]/g, "");
      var email = field("email").value.trim();
      var badName = name.length < 2;
      var badPhone = !/^(\+?91)?[6-9]\d{9}$/.test(phone);
      var badEmail = email !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
      setErr("name", badName); setErr("phone", badPhone); setErr("email", badEmail);
      if (badName || badPhone || badEmail) {
        ok = false;
        var first = form.querySelector(".invalid input");
        first && first.focus();
      }
      return ok;
    }
    function compose() {
      var lines = [
        "Hello Fire Boss, I would like to make an enquiry.",
        "",
        "Name: " + field("name").value.trim(),
        "Phone: " + field("phone").value.trim()
      ];
      var em = field("email").value.trim();
      if (em) lines.push("Email: " + em);
      var city = field("city").value.trim();
      if (city) lines.push("Location: " + city);
      lines.push("Requirement: " + field("topic").value);
      var msg = field("message").value.trim();
      if (msg) lines.push("", "Message: " + msg);
      if (list.length) {
        lines.push("", "Products of interest:");
        list.forEach(function (it, i) { lines.push((i + 1) + ". " + it.name); });
      }
      return lines.join("\n");
    }
    form.addEventListener("submit", function (e) { e.preventDefault(); });
    $$("[data-action]", form).forEach(function (b) {
      b.addEventListener("click", function () {
        if (!validate()) { toast("Please check the highlighted fields."); return; }
        var msg = compose();
        if (b.getAttribute("data-action") === "whatsapp") {
          window.open(waLink(msg), "_blank", "noopener");
          toast("Opening WhatsApp with your enquiry…");
        } else {
          var subject = "Enquiry from " + field("name").value.trim() + " — " + field("topic").value;
          window.location.href = "mailto:" + CFG.email + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(msg);
          toast("Opening your email app…");
        }
      });
    });
    ["name", "phone", "email"].forEach(function (n) {
      field(n).addEventListener("input", function () { field(n).closest(".field").classList.remove("invalid"); });
    });
    // pre-select topic from ?topic=
    var m = /[?&]topic=([^&]+)/.exec(location.search);
    if (m) {
      var want = decodeURIComponent(m[1].replace(/\+/g, " ")).toLowerCase();
      $$("option", field("topic")).forEach(function (o) { if (o.value.toLowerCase().indexOf(want) > -1) field("topic").value = o.value; });
    }
  }

  /* ---------- lightbox ---------- */
  function initLightbox() {
    var items = $$("[data-lightbox]");
    var lb = $("#lightbox");
    if (!items.length || !lb) return;
    var img = $("img", lb), cap = $("figcaption", lb), idx = 0, lastFocus;
    function show(i) {
      idx = (i + items.length) % items.length;
      var it = items[idx], im = $("img", it);
      img.src = it.getAttribute("data-full") || im.src;
      img.alt = im.alt;
      cap.textContent = it.getAttribute("data-caption") || im.alt;
    }
    function open(i) { lastFocus = document.activeElement; show(i); lb.classList.add("open"); document.body.style.overflow = "hidden"; $(".lb-close", lb).focus(); }
    function close() { lb.classList.remove("open"); document.body.style.overflow = ""; lastFocus && lastFocus.focus(); }
    items.forEach(function (it, i) { it.addEventListener("click", function () { open(i); }); });
    $(".lb-close", lb).addEventListener("click", close);
    $(".lb-prev", lb).addEventListener("click", function () { show(idx - 1); });
    $(".lb-next", lb).addEventListener("click", function () { show(idx + 1); });
    lb.addEventListener("click", function (e) { if (e.target === lb) close(); });
    document.addEventListener("keydown", function (e) {
      if (!lb.classList.contains("open")) return;
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") show(idx - 1);
      if (e.key === "ArrowRight") show(idx + 1);
    });
  }

  /* ---------- WhatsApp welcome bubble (once per session) ---------- */
  function initBubble() {
    var b = $("#wa-bubble");
    if (!b || flag("fb_bubble")) return;
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    setTimeout(function () {
      b.classList.add("show");
      setTimeout(function () { b.classList.remove("show"); }, 9000);
    }, reduce ? 2500 : 4500);
    $("button", b).addEventListener("click", function () { b.classList.remove("show"); });
    flag("fb_bubble", "1");
  }

  /* ---------- boot ---------- */
  document.addEventListener("DOMContentLoaded", function () {
    var y = $("#year"); if (y) y.textContent = new Date().getFullYear();
    wireWhatsApp();
    initHeader();
    initCounters();
    initEnquiry();
    initProducts();
    initContact();
    initLightbox();
    initReveal();
    initBubble();
  });
})();
